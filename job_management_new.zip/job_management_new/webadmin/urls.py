from django.urls import path
from .import views

urlpatterns = [
	path('',views.adminlogin,name='adminlogin'),
	path('admindash',views.admindash,name='admindash'),
	path('register',views.register,name='register'),
	path('showrecords',views.showrecords,name='showrecords'),
	path('stuedit',views.stuedit,name='stuesdit'),
	path('studel',views.studel,name='studel'),
	path('coursemaster',views.coursemaster,name='coursemaster'),
	path('viewcourses',views.viewcourses,name='viewcourses'),
	path('courseedit',views.courseedit,name='courseedit'),
	path('deletecourse',views.deletecourse,name='deletecourse'),
	path('logout',views.logout,name='logout'),
	path('approve',views.approve,name='approve'),
	path('hrrequest',views.hrrequest,name='hrrequest'),
	path('hrapprove',views.hrapprove,name='hrapprove'),
	path('postjobapproval',views.postjobapproval,name='postjobapproval'),
	path('jobstatus',views.jobstatus,name='jobstatus'),
]